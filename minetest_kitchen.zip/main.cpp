#include <iostream>
#include <vector>
#include <array>
#include <memory>
#include <irrlicht.h>

using namespace std;
using namespace irr;

#define MAX_LIGHTS_COUNT 10

IrrlichtDevice* device;
s32 lighting_mat;
io::path project_path = "/home/andrey/minetest_kitchen";

struct PointLight;

s32 lights_count = 0;
array<shared_ptr<PointLight>, MAX_LIGHTS_COUNT> lights;

struct PointLight
{
    core::vector3df pos;
    video::SColorf color;
    f32 intensity;

static shared_ptr<PointLight> addPointLight(const core::vector3df& spos, const video::SColor& scolor, const f32& sintensity)
{
    shared_ptr<PointLight> pl(new PointLight);

    pl->pos = spos;
    pl->color = video::SColorf(scolor.getRed() / 255.0f, scolor.getGreen() / 255.0f, scolor.getBlue() / 255.0f, scolor.getAlpha() / 255.0f);
    pl->intensity = sintensity;

    u32 free_id = 0;

    for (; free_id < MAX_LIGHTS_COUNT; free_id++)
        if (!lights[free_id])
            break;

    lights[free_id] = pl;

    lights_count++;

    return pl;
}
};

scene::ICameraSceneNode* camera = nullptr;

class SMaterialExt : public video::SMaterial
{
public:
    SMaterialExt() : video::SMaterial()
    {
        Roughness = 0.0f;
        Metallic = 0.0f;
        AO = 0.0f;
    }

    SMaterialExt(const SMaterialExt& mat): video::SMaterial(mat)
    {
        Roughness = mat.Roughness;
        Metallic = mat.Metallic;
        AO = mat.AO;
    }

    SMaterialExt& operator=(const SMaterialExt& mat)
    {
        if (this == &mat)
            return *this;

        (video::SMaterial&)*this = (video::SMaterial&)mat;

        Roughness = mat.Roughness;
        Metallic = mat.Metallic;
        AO = mat.AO;

        return *this;
    }

    f32 Roughness;
    f32 Metallic;
    f32 AO;
};

class MyEventReceiver : public IEventReceiver {
public:
    virtual bool OnEvent(const SEvent& e)
    {
        if (e.EventType == EET_KEY_INPUT_EVENT)
        {
            if (e.KeyInput.Key == KEY_ESCAPE)
            {
                device->closeDevice();
                return true;
            }
        }

        return false;
    }
};

class MyShaderConstantCallback : public video::IShaderConstantSetCallBack
{
public:
    const video::SMaterial* mat = nullptr;

    virtual void OnSetMaterial(const video::SMaterial& set_mat) { mat = &set_mat; }

    virtual void OnSetConstants(video::IMaterialRendererServices* services, s32 userdata)
    {
        video::IVideoDriver* vdrv = device->getVideoDriver();

        if ((s32)mat->MaterialType == lighting_mat)
        {
            core::matrix4 world = vdrv->getTransform(video::ETS_WORLD);
            core::matrix4 view = vdrv->getTransform(video::ETS_VIEW);
            core::matrix4 projection = vdrv->getTransform(video::ETS_PROJECTION);

            services->setVertexShaderConstant("mModel", world.pointer(), 16);
            services->setVertexShaderConstant("mView", view.pointer(), 16);
            services->setVertexShaderConstant("mProjection", projection.pointer(), 16);

            services->setPixelShaderConstant("mLightsCount", &lights_count, 1);

            f32 lights_positions[6];
            f32 lights_colors[8];
            f32 lights_intensities[2];

            for (int i = 0; i < lights_count; i++)
            {
                lights_positions[i*3] = lights[i]->pos.X;
                lights_positions[i*3+1] = lights[i]->pos.Y;
                lights_positions[i*3+2] = lights[i]->pos.Z;

                lights_colors[i*4] = lights[i]->color.getRed();
                lights_colors[i*4+1] = lights[i]->color.getGreen();
                lights_colors[i*4+2] = lights[i]->color.getBlue();
                lights_colors[i*4+3] = lights[i]->color.getAlpha();

                lights_intensities[i] = lights[i]->intensity;
            }

            services->setPixelShaderConstant("mLightsPositions", &(lights_positions[0]), 6);
            services->setPixelShaderConstant("mLightsColors", &(lights_colors[0]), 8);
            services->setPixelShaderConstant("mLightsIntensities", &(lights_intensities[0]), 2);

            core::vector3df cam_pos = camera->getAbsolutePosition();
            services->setPixelShaderConstant("mViewPos", reinterpret_cast<f32*>(&cam_pos), 3);

            float roughness = 0.4f;
            services->setPixelShaderConstant("mRoughness", &roughness, 1);

            float metallic = 1.0f;
            services->setPixelShaderConstant("mMetallic", &metallic, 1);

            float ao = 0.2f;
            services->setPixelShaderConstant("mAO", &ao, 1);

            s32 basetex_id = 0;
            s32 normaltex_id = 1;

            services->setPixelShaderConstant("mBaseTex", &basetex_id, 1);
            services->setPixelShaderConstant("mNormalTex", &normaltex_id, 1);
        }
    }
};

bool compileShaders(video::IShaderConstantSetCallBack* callback=nullptr)
{
    video::IVideoDriver* vdrv = device->getVideoDriver();
    video::IGPUProgrammingServices* gpu = vdrv->getGPUProgrammingServices();

    lighting_mat = gpu->addHighLevelShaderMaterialFromFiles(project_path + "/lighting.vert", "main", video::EVST_VS_1_1,
        project_path + "/lighting.frag", "main", video::EPST_PS_1_1, callback, video::EMT_SOLID, 0);

    return lighting_mat != 0;
}

int main()
{
    device = createDevice(video::EDT_OPENGL, core::dimension2du(1024, 680));

    MyEventReceiver receiver;
    device->setEventReceiver(&receiver);

    MyShaderConstantCallback callback;

    bool success = compileShaders(&callback);

    if (!success)
        cerr << "Shaders failed to compile!" << endl;

    video::IVideoDriver* vdrv = device->getVideoDriver();
    scene::ISceneManager* smgr = device->getSceneManager();

    //scene::IMeshSceneNode* table = smgr->addMeshSceneNode(smgr->getMesh(project_path + "/multidecor_kitchen_modern_wooden_table.b3d"));

    SMaterialExt table_mat_wood;
    table_mat_wood.Lighting = false;
    table_mat_wood.NormalizeNormals = true;
    table_mat_wood.BackfaceCulling = false;
    table_mat_wood.setFlag(video::EMF_BILINEAR_FILTER, false);
    table_mat_wood.MaterialType = (video::E_MATERIAL_TYPE)lighting_mat;

    SMaterialExt table_mat_wool(table_mat_wood);

    table_mat_wood.Roughness = 0.7f;
    table_mat_wood.Metallic = 0.2f;
    table_mat_wood.AO = 0.2f;
    table_mat_wood.setTexture(0, vdrv->getTexture(project_path + "/sphere.png"));
    video::ITexture* normal_map = vdrv->getTexture(project_path + "/normalmap.png");
    vdrv->makeNormalMapTexture(normal_map, 0.9f);
    table_mat_wood.setTexture(1, normal_map);
    //table->getMaterial(1) = table_mat_wood;

    table_mat_wool.Roughness = 1.0f;
    table_mat_wool.Metallic = 0.05f;
    table_mat_wool.AO = 0.2f;
    video::ITexture* wool_tex = vdrv->getTexture(project_path + "/multidecor_wool_material.png");
    table_mat_wool.setTexture(0, wool_tex);
    //video::ITexture* normal_map2 = vdrv->getTexture(project_path + "/multidecor_wool_material_nm.png");
    //vdrv->makeNormalMapTexture(, 0.9f);
    vdrv->makeNormalMapTexture(wool_tex, 0.9f);
    table_mat_wool.setTexture(1, wool_tex);
    //table->getMaterial(0) = table_mat_wool;
    //table->getMaterial(2) = table_mat_wool;

    scene::IMeshSceneNode* sphere = smgr->addSphereSceneNode(1.0f, 32);
    sphere->getMaterial(0) = table_mat_wood;


    auto pl_1 = PointLight::addPointLight(core::vector3df(7.0f, 3.0f, 0.0f), video::SColor(255, 255, 255, 255), 0.4f);
    auto pl_2 = PointLight::addPointLight(core::vector3df(-12.0f, 1.5f, 2.0f), video::SColor(255, 255, 255, 255), 0.7f);

    vdrv->setTextureCreationFlag(video::ETCF_CREATE_MIP_MAPS, false);

    video::ITexture* tiles = vdrv->getTexture(project_path + "/ceramic_tiles.png");
    smgr->addSkyBoxSceneNode(tiles, tiles, tiles, tiles, tiles, tiles);

    vdrv->setTextureCreationFlag(video::ETCF_CREATE_MIP_MAPS, true);

    camera = smgr->addCameraSceneNodeFPS(0, 100.0f, 0.01f);
    camera->setPosition(core::vector3df(0.0f, 0.0f, -5.0f));
    camera->setTarget(core::vector3df(0.0f));

    while(device->run())
    {
        if (device->isWindowActive())
        {
            std::wstring name = L"Minetest Kitchen App | FPS: ";
            std::wstring str = name + std::to_wstring(vdrv->getFPS());

            device->setWindowCaption(str.c_str());

            vdrv->beginScene(video::ECBF_COLOR | video::ECBF_DEPTH, video::SColor(255, 255, 255, 255));

            smgr->drawAll();

            vdrv->endScene();
        }
    }


    return 0;
}
